package com.example.gamebrowser.data.model.dto

data class ScreenshotDto(
    val id: Int,
    val image: String
)
