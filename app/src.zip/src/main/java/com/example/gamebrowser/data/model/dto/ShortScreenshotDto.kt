package com.example.gamebrowser.data.model.dto

data class ShortScreenshotDto(
    val id: Int,
    val image: String
)