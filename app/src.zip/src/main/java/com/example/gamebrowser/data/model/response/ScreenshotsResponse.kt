package com.example.gamebrowser.data.model.response

import com.example.gamebrowser.data.model.dto.ShortScreenshotDto

data class ScreenshotsResponse(
    val results: List<ShortScreenshotDto>
)
