package com.example.gamebrowser.data.model.dto


data class PlatformWrapperDto(
    val platform: PlatformDto
)