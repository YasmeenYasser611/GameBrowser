package com.example.gamebrowser.data.model.dto

data class PlatformDto(
    val id: Int,
    val name: String
)
