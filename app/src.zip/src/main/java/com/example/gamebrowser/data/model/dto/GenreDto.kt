package com.example.gamebrowser.data.model.dto

data class GenreDto(
    val id: Int,
    val name: String
)