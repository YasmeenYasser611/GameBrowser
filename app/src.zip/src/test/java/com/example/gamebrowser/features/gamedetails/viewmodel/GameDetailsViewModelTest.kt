package com.example.gamebrowser.features.gamedetails.viewmodel

import androidx.lifecycle.SavedStateHandle
import com.example.gamebrowser.data.model.dto.*
import com.example.gamebrowser.data.repository.IGameRepository
import io.mockk.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*

@OptIn(ExperimentalCoroutinesApi::class)
class GameDetailsViewModelTest {

    // Dependencies
    private lateinit var repository: IGameRepository
    private lateinit var savedStateHandle: SavedStateHandle
    private lateinit var viewModel: GameDetailsViewModel

    // Test dispatcher
    private val testDispatcher = StandardTestDispatcher()

    // Test data
    private val testGameId = 123
    private val testGame = GameDto(
        id = testGameId,
        name = "Test Game",
        description = "Test Description",
        descriptionRaw = "Test Raw Description",
        imageUrl = "https://example.com/image.jpg",
        rating = 4.5,
        releaseDate = "2024-01-15",
        metacriticScore = 85,
        genres = listOf(
            GenreDto(id = 1, name = "Action"),
            GenreDto(id = 2, name = "Adventure")
        ),
        platforms = listOf(
            PlatformWrapperDto(
                platform = PlatformDto(id = 1, name = "PlayStation 5")
            ),
            PlatformWrapperDto(
                platform = PlatformDto(id = 2, name = "Xbox Series X")
            )
        ),
        clip = null,
        shortScreenshots = null
    )

    private val testScreenshots = listOf(
        ScreenshotDto(id = 1, image = "https://example.com/screenshot1.jpg"),
        ScreenshotDto(id = 2, image = "https://example.com/screenshot2.jpg"),
        ScreenshotDto(id = 3, image = "https://example.com/screenshot3.jpg")
    )

    private val testMovies = listOf(
        GameMovieDto(
            id = 1,
            data = MovieDataDto(
                max = "https://example.com/trailer_max.mp4",
                `480` = "https://example.com/trailer_480.mp4"
            )
        )
    )

    @Before
    fun setup() {
        // Set up test dispatcher
        Dispatchers.setMain(testDispatcher)

        // Create mocks
        repository = mockk(relaxed = true)
        savedStateHandle = mockk(relaxed = true)

        // Default stub for savedStateHandle
        every { savedStateHandle.get<String>("gameId") } returns testGameId.toString()
    }

    @After
    fun tearDown() {
        // Reset main dispatcher
        Dispatchers.resetMain()
    }

    // ==================== INITIALIZATION TESTS ====================

    @Test
    fun init_validGameId_loadsGameDetails() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
        coEvery { repository.getGameMovies(testGameId) } returns testMovies

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle() // Wait for all coroutines to complete

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Success)
        assertEquals(testGame.name, (state as GameDetailsUiState.Success).game.name)
    }

    @Test
    fun init_invalidGameId_setsErrorState() = runTest {
        // Arrange
        every { savedStateHandle.get<String>("gameId") } returns "invalid"

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Error)
        assertEquals("Invalid game ID", (state as GameDetailsUiState.Error).message)
    }

    @Test
    fun init_nullGameId_setsErrorState() = runTest {
        // Arrange
        every { savedStateHandle.get<String>("gameId") } returns null

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Error)
        assertEquals("Invalid game ID", (state as GameDetailsUiState.Error).message)
    }

    // ==================== SUCCESS CASES ====================

    @Test
    fun loadGameDetails_success_allDataLoaded() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
        coEvery { repository.getGameMovies(testGameId) } returns testMovies

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals(testGame, state.game)
        assertEquals(3, state.screenshots.size)
        assertEquals("https://example.com/trailer_max.mp4", state.trailerUrl)
    }

    @Test
    fun loadGameDetails_success_formatsGenresCorrectly() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("Action, Adventure", state.genresText)
    }

    @Test
    fun loadGameDetails_success_formatsPlatformsCorrectly() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("PlayStation 5, Xbox Series X", state.platformsText)
    }

    @Test
    fun loadGameDetails_success_formatsReleaseDateCorrectly() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("2024-01-15", state.releaseDateFormatted)
    }

    @Test
    fun loadGameDetails_noGenres_showsNoGenresMessage() = runTest {
        // Arrange
        val gameNoGenres = testGame.copy(genres = emptyList())
        coEvery { repository.getGameDetails(testGameId) } returns gameNoGenres
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("No genres available", state.genresText)
    }

    @Test
    fun loadGameDetails_noPlatforms_showsNoPlatformsMessage() = runTest {
        // Arrange
        val gameNoPlatforms = testGame.copy(platforms = emptyList())
        coEvery { repository.getGameDetails(testGameId) } returns gameNoPlatforms
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("No platforms available", state.platformsText)
    }

    @Test
    fun loadGameDetails_moreThanFivePlatforms_truncatesWithAndMore() = runTest {
        // Arrange
        val manyPlatforms = (1..7).map { id ->
            PlatformWrapperDto(platform = PlatformDto(id = id, name = "Platform $id"))
        }
        val gameWithManyPlatforms = testGame.copy(platforms = manyPlatforms)
        coEvery { repository.getGameDetails(testGameId) } returns gameWithManyPlatforms
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertTrue(state.platformsText.contains("and more"))
        assertTrue(state.platformsText.split(",").size <= 5)
    }

    @Test
    fun loadGameDetails_nullReleaseDate_showsUnknownMessage() = runTest {
        // Arrange
        val gameNoReleaseDate = testGame.copy(releaseDate = null)
        coEvery { repository.getGameDetails(testGameId) } returns gameNoReleaseDate
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("Release date unknown", state.releaseDateFormatted)
    }

    // ==================== TRAILER URL TESTS ====================

    @Test
    fun getTrailerUrl_fromMovies_returnsMaxQuality() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns testMovies

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("https://example.com/trailer_max.mp4", state.trailerUrl)
    }

    @Test
    fun getTrailerUrl_fromMovies_fallbackTo480Quality() = runTest {
        // Arrange
        val movieWith480Only = GameMovieDto(
            id = 1,
            data = MovieDataDto(max = null, `480` = "https://example.com/trailer_480.mp4")
        )
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns listOf(movieWith480Only)

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("https://example.com/trailer_480.mp4", state.trailerUrl)
    }

    @Test
    fun getTrailerUrl_fromClip_returnsQuality640() = runTest {
        // Arrange
        val gameWithClip = testGame.copy(
            clip = ClipDto(
                clip = null,
                video = null,
                preview = null,
                clipsWrapper = ClipsWrapper(
                    quality320 = null,
                    quality640 = "https://example.com/clip_640.mp4",
                    full = "https://example.com/clip_full.mp4"
                )
            )
        )
        coEvery { repository.getGameDetails(testGameId) } returns gameWithClip
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("https://example.com/clip_640.mp4", state.trailerUrl)
    }

    @Test
    fun getTrailerUrl_fromClip_fallbackToFull() = runTest {
        // Arrange
        val gameWithClip = testGame.copy(
            clip = ClipDto(
                clip = null,
                video = null,
                preview = null,
                clipsWrapper = ClipsWrapper(
                    quality320 = null,
                    quality640 = null,
                    full = "https://example.com/clip_full.mp4"
                )
            )
        )
        coEvery { repository.getGameDetails(testGameId) } returns gameWithClip
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertEquals("https://example.com/clip_full.mp4", state.trailerUrl)
    }

    @Test
    fun getTrailerUrl_noTrailerAvailable_returnsNull() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value as GameDetailsUiState.Success
        assertNull(state.trailerUrl)
    }

    // ==================== ERROR CASES ====================

    @Test
    fun loadGameDetails_nullGame_setsErrorState() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns null
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Error)
        assertEquals("Game not found", (state as GameDetailsUiState.Error).message)
    }

    @Test
    fun loadGameDetails_repositoryThrowsException_setsErrorState() = runTest {
        // Arrange
        val exceptionMessage = "Network error"
        coEvery { repository.getGameDetails(testGameId) } throws Exception(exceptionMessage)

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Error)
        assertEquals(exceptionMessage, (state as GameDetailsUiState.Error).message)
    }

    @Test
    fun loadGameDetails_exceptionWithoutMessage_usesDefaultMessage() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } throws Exception()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Error)
        assertEquals("Failed to load game details", (state as GameDetailsUiState.Error).message)
    }

    // ==================== RETRY TESTS ====================

    @Test
    fun retry_validGameId_reloadsGameDetails() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } returns testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
        coEvery { repository.getGameMovies(testGameId) } returns testMovies

        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Act
        viewModel.retry()
        advanceUntilIdle()

        // Assert
        coVerify(exactly = 2) { repository.getGameDetails(testGameId) }
        coVerify(exactly = 2) { repository.getGameScreenshots(testGameId) }
        coVerify(exactly = 2) { repository.getGameMovies(testGameId) }
    }

    @Test
    fun retry_invalidGameId_setsErrorState() = runTest {
        // Arrange
        every { savedStateHandle.get<String>("gameId") } returns null
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Act
        viewModel.retry()
        advanceUntilIdle()

        // Assert
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Error)
        assertEquals("Invalid game ID", (state as GameDetailsUiState.Error).message)
    }

    @Test
    fun retry_afterError_loadsSuccessfully() = runTest {
        // Arrange - First call throws exception
        coEvery { repository.getGameDetails(testGameId) } throws Exception("Network error") andThen testGame
        coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
        coEvery { repository.getGameMovies(testGameId) } returns testMovies

        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Verify initial error state
        assertTrue(viewModel.uiState.value is GameDetailsUiState.Error)

        // Act - Retry
        viewModel.retry()
        advanceUntilIdle()

        // Assert - Now it should be success
        val state = viewModel.uiState.value
        assertTrue(state is GameDetailsUiState.Success)
        assertEquals(testGame.name, (state as GameDetailsUiState.Success).game.name)
    }

    // ==================== LOADING STATE TESTS ====================

    @Test
    fun loadGameDetails_setsLoadingStateFirst() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } coAnswers {
            // Delay to capture loading state
            kotlinx.coroutines.delay(100)
            testGame
        }
        coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
        coEvery { repository.getGameMovies(testGameId) } returns emptyList()

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)

        // Assert - Should be loading before coroutines complete
        assertTrue(viewModel.uiState.value is GameDetailsUiState.Loading)

        advanceUntilIdle()

        // Should be success after completion
        assertTrue(viewModel.uiState.value is GameDetailsUiState.Success)
    }

    // ==================== PARALLEL LOADING TESTS ====================

    @Test
    fun loadGameDetails_loadsDataInParallel() = runTest {
        // Arrange
        coEvery { repository.getGameDetails(testGameId) } coAnswers {
            kotlinx.coroutines.delay(50)
            testGame
        }
        coEvery { repository.getGameScreenshots(testGameId) } coAnswers {
            kotlinx.coroutines.delay(50)
            testScreenshots
        }
        coEvery { repository.getGameMovies(testGameId) } coAnswers {
            kotlinx.coroutines.delay(50)
            testMovies
        }

        // Act
        viewModel = GameDetailsViewModel(repository, savedStateHandle)
        advanceUntilIdle()

        // Assert - All three should be called
        coVerify { repository.getGameDetails(testGameId) }
        coVerify { repository.getGameScreenshots(testGameId) }
        coVerify { repository.getGameMovies(testGameId) }
    }
}


@Before
fun setup() {
    // Set up test dispatcher
    Dispatchers.setMain(testDispatcher)

    // Create mocks
    repository = mockk(relaxed = true)
    savedStateHandle = mockk(relaxed = true)

    // Default stub for savedStateHandle
    every { savedStateHandle.get<String>("gameId") } returns testGameId.toString()
}

@After
fun tearDown() {
    // Reset main dispatcher
    Dispatchers.resetMain()
}

// ==================== INITIALIZATION TESTS ====================

@Test
fun init_validGameId_loadsGameDetails() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
    coEvery { repository.getGameMovies(testGameId) } returns testMovies

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle() // Wait for all coroutines to complete

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Success)
    assertEquals(testGame.name, (state as GameDetailsUiState.Success).game.name)
}

@Test
fun init_invalidGameId_setsErrorState() = runTest {
    // Arrange
    every { savedStateHandle.get<String>("gameId") } returns "invalid"

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Error)
    assertEquals("Invalid game ID", (state as GameDetailsUiState.Error).message)
}

@Test
fun init_nullGameId_setsErrorState() = runTest {
    // Arrange
    every { savedStateHandle.get<String>("gameId") } returns null

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Error)
    assertEquals("Invalid game ID", (state as GameDetailsUiState.Error).message)
}

// ==================== SUCCESS CASES ====================

@Test
fun loadGameDetails_success_allDataLoaded() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
    coEvery { repository.getGameMovies(testGameId) } returns testMovies

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals(testGame, state.game)
    assertEquals(3, state.screenshots.size)
    assertEquals("https://example.com/trailer_max.mp4", state.trailerUrl)
}

@Test
fun loadGameDetails_success_formatsGenresCorrectly() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("Action, Adventure", state.genresText)
}

@Test
fun loadGameDetails_success_formatsPlatformsCorrectly() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("PlayStation 5, Xbox Series X", state.platformsText)
}

@Test
fun loadGameDetails_success_formatsReleaseDateCorrectly() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("2024-01-15", state.releaseDateFormatted)
}

@Test
fun loadGameDetails_noGenres_showsNoGenresMessage() = runTest {
    // Arrange
    val gameNoGenres = testGame.copy(genres = emptyList())
    coEvery { repository.getGameDetails(testGameId) } returns gameNoGenres
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("No genres available", state.genresText)
}

@Test
fun loadGameDetails_noPlatforms_showsNoPlatformsMessage() = runTest {
    // Arrange
    val gameNoPlatforms = testGame.copy(platforms = emptyList())
    coEvery { repository.getGameDetails(testGameId) } returns gameNoPlatforms
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("No platforms available", state.platformsText)
}

@Test
fun loadGameDetails_moreThanFivePlatforms_truncatesWithAndMore() = runTest {
    // Arrange
    val manyPlatforms = (1..7).map { id ->
        PlatformWrapperDto(platform = PlatformDto(id = id, name = "Platform $id"))
    }
    val gameWithManyPlatforms = testGame.copy(platforms = manyPlatforms)
    coEvery { repository.getGameDetails(testGameId) } returns gameWithManyPlatforms
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertTrue(state.platformsText.contains("and more"))
    assertTrue(state.platformsText.split(",").size <= 5)
}

@Test
fun loadGameDetails_nullReleaseDate_showsUnknownMessage() = runTest {
    // Arrange
    val gameNoReleaseDate = testGame.copy(releaseDate = null)
    coEvery { repository.getGameDetails(testGameId) } returns gameNoReleaseDate
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("Release date unknown", state.releaseDateFormatted)
}

// ==================== TRAILER URL TESTS ====================

@Test
fun getTrailerUrl_fromMovies_returnsMaxQuality() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns testMovies

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("https://example.com/trailer_max.mp4", state.trailerUrl)
}

@Test
fun getTrailerUrl_fromMovies_fallbackTo480Quality() = runTest {
    // Arrange
    val movieWith480Only = GameMovieDto(
        id = 1,
        name = "Trailer",
        preview = "preview.jpg",
        data = MovieDataDto(max = null, `480` = "https://example.com/trailer_480.mp4")
    )
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns listOf(movieWith480Only)

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("https://example.com/trailer_480.mp4", state.trailerUrl)
}

@Test
fun getTrailerUrl_fromClip_returnsQuality640() = runTest {
    // Arrange
    val gameWithClip = testGame.copy(
        clip = ClipDto(
            clip = null,
            video = null,
            clipsWrapper = ClipsWrapperDto(
                quality640 = "https://example.com/clip_640.mp4",
                full = "https://example.com/clip_full.mp4"
            )
        )
    )
    coEvery { repository.getGameDetails(testGameId) } returns gameWithClip
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertEquals("https://example.com/clip_640.mp4", state.trailerUrl)
}

@Test
fun getTrailerUrl_noTrailerAvailable_returnsNull() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value as GameDetailsUiState.Success
    assertNull(state.trailerUrl)
}

// ==================== ERROR CASES ====================

@Test
fun loadGameDetails_nullGame_setsErrorState() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns null
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Error)
    assertEquals("Game not found", (state as GameDetailsUiState.Error).message)
}

@Test
fun loadGameDetails_repositoryThrowsException_setsErrorState() = runTest {
    // Arrange
    val exceptionMessage = "Network error"
    coEvery { repository.getGameDetails(testGameId) } throws Exception(exceptionMessage)

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Error)
    assertEquals(exceptionMessage, (state as GameDetailsUiState.Error).message)
}

@Test
fun loadGameDetails_exceptionWithoutMessage_usesDefaultMessage() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } throws Exception()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Error)
    assertEquals("Failed to load game details", (state as GameDetailsUiState.Error).message)
}

// ==================== RETRY TESTS ====================

@Test
fun retry_validGameId_reloadsGameDetails() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } returns testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
    coEvery { repository.getGameMovies(testGameId) } returns testMovies

    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Act
    viewModel.retry()
    advanceUntilIdle()

    // Assert
    coVerify(exactly = 2) { repository.getGameDetails(testGameId) }
    coVerify(exactly = 2) { repository.getGameScreenshots(testGameId) }
    coVerify(exactly = 2) { repository.getGameMovies(testGameId) }
}

@Test
fun retry_invalidGameId_setsErrorState() = runTest {
    // Arrange
    every { savedStateHandle.get<String>("gameId") } returns null
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Act
    viewModel.retry()
    advanceUntilIdle()

    // Assert
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Error)
    assertEquals("Invalid game ID", (state as GameDetailsUiState.Error).message)
}

@Test
fun retry_afterError_loadsSuccessfully() = runTest {
    // Arrange - First call throws exception
    coEvery { repository.getGameDetails(testGameId) } throws Exception("Network error") andThen testGame
    coEvery { repository.getGameScreenshots(testGameId) } returns testScreenshots
    coEvery { repository.getGameMovies(testGameId) } returns testMovies

    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Verify initial error state
    assertTrue(viewModel.uiState.value is GameDetailsUiState.Error)

    // Act - Retry
    viewModel.retry()
    advanceUntilIdle()

    // Assert - Now it should be success
    val state = viewModel.uiState.value
    assertTrue(state is GameDetailsUiState.Success)
    assertEquals(testGame.name, (state as GameDetailsUiState.Success).game.name)
}

// ==================== LOADING STATE TESTS ====================

@Test
fun loadGameDetails_setsLoadingStateFirst() = runTest {
    // Arrange
    coEvery { repository.getGameDetails(testGameId) } coAnswers {
        // Delay to capture loading state
        kotlinx.coroutines.delay(100)
        testGame
    }
    coEvery { repository.getGameScreenshots(testGameId) } returns emptyList()
    coEvery { repository.getGameMovies(testGameId) } returns emptyList()

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)

    // Assert - Should be loading before coroutines complete
    assertTrue(viewModel.uiState.value is GameDetailsUiState.Loading)

    advanceUntilIdle()

    // Should be success after completion
    assertTrue(viewModel.uiState.value is GameDetailsUiState.Success)
}

// ==================== PARALLEL LOADING TESTS ====================

@Test
fun loadGameDetails_loadsDataInParallel() = runTest {
    // Arrange
    var gameCallTime = 0L
    var screenshotsCallTime = 0L
    var moviesCallTime = 0L

    coEvery { repository.getGameDetails(testGameId) } coAnswers {
        gameCallTime = System.currentTimeMillis()
        kotlinx.coroutines.delay(50)
        testGame
    }
    coEvery { repository.getGameScreenshots(testGameId) } coAnswers {
        screenshotsCallTime = System.currentTimeMillis()
        kotlinx.coroutines.delay(50)
        testScreenshots
    }
    coEvery { repository.getGameMovies(testGameId) } coAnswers {
        moviesCallTime = System.currentTimeMillis()
        kotlinx.coroutines.delay(50)
        testMovies
    }

    // Act
    viewModel = GameDetailsViewModel(repository, savedStateHandle)
    advanceUntilIdle()

    // Assert - All three should be called (times may vary in tests, but all should be called)
    coVerify { repository.getGameDetails(testGameId) }
    coVerify { repository.getGameScreenshots(testGameId) }
    coVerify { repository.getGameMovies(testGameId) }
}
}